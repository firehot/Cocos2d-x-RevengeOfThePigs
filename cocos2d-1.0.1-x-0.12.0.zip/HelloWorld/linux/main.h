#ifndef __MAIN_H__
#define __MAIN_H__

// C RunTime Header Files
#include "CCStdC.h"

#endif	// __MAIN_H__
